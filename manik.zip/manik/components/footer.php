<footer class="footer">

   <section class="grid">

      <div class="box">
         <h3>Quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> Home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> About</a>
         <a href="shop.php"> <i class="fas fa-angle-right"></i> Shop</a>
         <a href="contact.php"> <i class="fas fa-angle-right"></i> Contact</a>
      </div>

      <div class="box">
         <h3>Extra links</h3>
         <a href="user_login.php"> <i class="fas fa-angle-right"></i> Login</a>
         <a href="user_register.php"> <i class="fas fa-angle-right"></i> Register</a>
         <a href="cart.php"> <i class="fas fa-angle-right"></i> Cart</a>
         <a href="orders.php"> <i class="fas fa-angle-right"></i> Orders</a>
      </div>

      <div class="box">
         <h3>Contact Us.</h3>
         <a href="tel:01776661172"><i class="fas fa-phone"></i> 01776661172</a>
         <a href="tel:01628598527"><i class="fas fa-phone"></i> 01628598527</a>
         <a href="mailto:manik15-3981@diu.edu.bd"><i class="fas fa-envelope"></i> manik15-3981@diu.edu.bd</a>
         <a href="https://www.google.com/maps/place/Daffodil+Smart+City/@23.872736,90.321182,16z/data=!4m6!3m5!1s0x3755c23dd12bbc75:0x313d214552eabe56!8m2!3d23.8756013!4d90.3203018!16s%2Fg%2F11n_xzl12w?hl=en&entry=ttu"><i class="fas fa-map-marker-alt"></i> Birulia, Savar, Dhaka-1216</a>
      </div>

      <div class="box">
         <h3>Follow Us</h3>
         <a href="https://www.facebook.com/mdasgaralimanik?mibextid=ZbWKwL" target="_blank"><i class="fab fa-facebook-f"></i>facebook</a>
         <a href="https://x.com/mdasgaralimanik?t=cfmVv5T-MtErM0hT1_DUFw&s=09" target="_blank"><i class="fab fa-twitter"></i>Twitter</a>
         <a href="https://www.instagram.com/md_asgar_ali_manik?igsh=NGo2cml6a2oyNDVq" target="_blank"><i class="fab fa-instagram"></i>Instagram</a>
         <a href="https://www.linkedin.com/in/md-asgar-ali-manik" target="_blank"><i class="fab fa-linkedin"></i>Linkedin</a>
      </div>

   </section>

   <div class="credit">&copy; copyright @ <?= date('Y'); ?> by <span>MD. ASGAR ALI MANIK</span> | all rights reserved!</div>

</footer>